# pickit
Diablo II - LLD pickit levels 9-49

Replace your LLD.nip with this one - pick a variety of stuff!
Something is missing, wrong or not worth picking? Please use Issues/Pull requests!
